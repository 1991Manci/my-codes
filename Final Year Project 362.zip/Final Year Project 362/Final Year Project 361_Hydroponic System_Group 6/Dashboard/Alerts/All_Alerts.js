document.addEventListener("DOMContentLoaded", function () {
    const criticalButton = document.getElementById("critical-button");
    const warningButton = document.getElementById("warning-button");
    const harvestButton = document.getElementById("harvest-button");
    const cards = document.querySelectorAll(".card");

    // Show details for all cards by default
    cards.forEach(card => {
        const details = card.querySelector(".card-details");
        details.style.display = "block"; 
    });

    criticalButton.addEventListener("click", () => filterCards("critical"));
    warningButton.addEventListener("click", () => filterCards("warning"));
    harvestButton.addEventListener("click", () => filterCards("harvest"));

    function filterCards(category) {
        cards.forEach(card => {
            card.style.display = "none";
        });
        const filteredCards = document.querySelectorAll(`.${category}`);
        filteredCards.forEach(card => {
            card.style.display = "block";
        });
    }

    window.showAllCards = function() {
        cards.forEach(card => {
            card.style.display = "block";
        });
    };
});
