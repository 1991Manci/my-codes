//import './style.css'
//import javascriptLogo from './javascript.svg'
//import viteLogo from '/vite.svg'
//import { setupCounter } from './counter.js'
//import './require.js';
//const fs = require(['fs']);
//define(function (require) {
//  const fs = require('fs');
//});
//const readLastLines = require(['read-last-lines']);
//define(function (require) {
 // const readLastLines = require(['read-last-lines']);
 // readLastLines.read('./demo.txt', 24)
//.then((lines) => console.log(lines));
//});

//requirejs(["lib/index"], 
//function (readLastLines) {
 // readLastLines.read('./demo.txt', 24)
 // .then((lines) => console.log(lines));
//});

const readLastLines = require('read-last-lines');
readLastLines.read("js/demo.txt", 24)
  .then((lines) => console.log(lines));
