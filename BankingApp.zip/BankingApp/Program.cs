﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApp
{
    class Program
    {
        enum Menu
        {
            Send_Money = 1,                               // Send money option
            Buy_Airtime,                                 // Buy airtime option
            Check_Balance,                              // Check balance option
            Exit                                        // Exit option
        }

        // This method is used to handle the user login process
        static bool Logon()
        {
            // Initialize the Login variable to false, indicating that the user is not logged in         
            bool Login = false;
            // Initialize the Continue variable to true, which controls the login attempt loop
            bool Continue = true;
            // Initialize the Counter variable to keep track of login attempts
            int Counter = 0;

            while (Continue)
            {
                Console.Clear();
                // Prompt the user to enter a username
                Console.WriteLine("Please enter a username: ");

                if(Console.ReadLine() == "abcd")
                {
                    // If the entered username is correct, prompt for a password
                    Console.WriteLine("Please enter your password: ");

                    if (Console.ReadLine() == "1234")
                    {
                        // If the entered password is correct, set Login to true and exit the loop.
                        Login = true;
                        Login = true;
                        Continue = false;
                       
                    }
                    else
                    {
                        // If the entered password is incorrect, inform the user, increment the login attempt counter, and wait for user input.
                        Console.WriteLine("The password provided is wrong");
                        Counter++;
                        Console.ReadLine();
                    }

                }
                else 
                {
              // If the entered username is incorrect, inform the user, increment the login attempt counter, and wait for user input
                    Console.WriteLine("The username provided is wrong");
                    Counter++;
                    Console.ReadLine();
                }

                if (Counter== 3)
                {
             // If the user has reached the maximum allowed login attempts, exit the loop and inform the user
                    Continue = false;
                    Console.WriteLine("You have tried to log in too many times");
                        Console.ReadLine(); 
                }          
            }
            // Return the value of Login after the login process is completed
            return Login;
        }
 // This method is responsible for displaying the user interface and handling user input
        static void Display()
        {
            
            bool Login = Logon();
            if (Login == true)
            {
                bool Continue = true;
                int Amount = 1000;
                while (Continue)
                {
                    // Display the menu options
                    Console.Clear();
                    Console.WriteLine("1. Send Money");
                    Console.WriteLine("2. Buy Airtime");
                    Console.WriteLine("3. Check Balance");
                    Console.WriteLine("4. Exit");
                    Console.WriteLine("Please select an option:");
                    // Read the user's choice as an integer
                    int choice = int.Parse(Console.ReadLine());
                    // Cast the integer choice to the Menu enumeration to match the selected option
                    Menu Main = (Menu)choice;
                    // Initialize a variable to store the selected value, if necessary for further processing
                    int Value;
                    // Handle user's menu selection based on the 'Main' enumeration
                    switch (Main)
                    {
                        case Menu.Send_Money:
                            // User selected 'Send Money' option
                            Console.WriteLine("How much do you want to send?");
                            Value = int.Parse(Console.ReadLine());
                            Amount -= Value;
                            Console.WriteLine("The amount of money you have left is: "+Amount);
                            Console.ReadLine();
                            break;
                        case Menu.Buy_Airtime:
                            // User selected 'Buy Airtime' option
                            Console.WriteLine("How much airtime do you want to buy?");
                            Value = int.Parse(Console.ReadLine());
                            Amount -= Value;
                            Console.WriteLine("The amount of money you have left is: " + Amount);
                            Console.ReadLine();
                            break;
                        case Menu.Check_Balance:
                            // User selected 'Check Balance' option.
                            Console.WriteLine("Your balance is:" + Amount);
                            Console.ReadLine();
                            break;
                        case Menu.Exit:
                            // User selected 'Exit' option, so we exit the loop
                            Continue = false;
                            break;
                        default:
                            break;
                    }
                }
            }
        }


        // The entry point of the program
        static void Main(string[] args)
        {
            // Call the Display method to start the application and display the user interface
            Display();

        }
    }
}
