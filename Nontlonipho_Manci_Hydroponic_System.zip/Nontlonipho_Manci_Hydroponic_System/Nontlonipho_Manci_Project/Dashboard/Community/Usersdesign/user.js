// @ts-nocheck

const johnSelectorBtn = document.querySelector("#john-selector");
const janeSelectorBtn = document.querySelector("#jane-selector");
const shereenSelectorBtn = document.querySelector("#shereen-selector");
const vusiSelectorBtn = document.querySelector("#vusi-selector");
const nicolasSelectorBtn = document.querySelector("#nicolas-selector");
const sinhleSelectorBtn = document.querySelector("#sinhle-selector");
const ntlonieSelectorBtn = document.querySelector("#ntlonie-selector");
const chatHeader = document.querySelector(".chat-header");
const chatMessages = document.querySelector(".chat-messages");
const chatInputForm = document.querySelector(".chat-input-form");
const chatInput = document.querySelector(".chat-input");
const clearChatBtn = document.querySelector(".clear-chat-button");

const messages = JSON.parse(localStorage.getItem("messages")) || [];

const createChatMessageElement = (message) => `
  <div class="message ${message.sender === "John" ? "blue-bg" : "gray-bg"}">
    <div class="message-sender">${message.sender}</div>
    <div class="message-text">${message.text}</div>
    <div class="message-timestamp">${message.timestamp}</div>
  </div>
`;

window.onload = () => {
  messages.forEach((message) => {
    chatMessages.innerHTML += createChatMessageElement(message);
  });
};

let messageSender = "John";

const updateMessageSender = (name) => {
  messageSender = name;
  chatHeader.innerText = `${messageSender} chatting...`;
  chatInput.placeholder = `Type here, ${messageSender}...`;

  if (name === "John") {
    johnSelectorBtn.classList.add("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
  }
  if (name === "Jane") {
    janeSelectorBtn.classList.add("active-person");
    johnSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
  }
  if (name === "Shereen") {
    johnSelectorBtn.classList.add("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
  }
  if (name === "Vusi") {
    janeSelectorBtn.classList.add("active-person");
    johnSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
  }
  if (name === "Sinhle") {
    johnSelectorBtn.classList.add("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
  }
  if (name === "Nicolas") {
    janeSelectorBtn.classList.add("active-person");
    johnSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
  }
  if (name === "Ntlonie") {
    johnSelectorBtn.classList.add("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");
    janeSelectorBtn.classList.remove("active-person");

  }

  /* auto-focus the input field */
  chatInput.focus();
};

johnSelectorBtn.onclick = () => updateMessageSender("John");
janeSelectorBtn.onclick = () => updateMessageSender("Jane");
johnSelectorBtn.onclick = () => updateMessageSender("Shereen");
janeSelectorBtn.onclick = () => updateMessageSender("Sinhle");
johnSelectorBtn.onclick = () => updateMessageSender("Ntlonie");
janeSelectorBtn.onclick = () => updateMessageSender("Nicolas");
johnSelectorBtn.onclick = () => updateMessageSender("Vusi");

const sendMessage = (e) => {
  e.preventDefault();

  const timestamp = new Date().toLocaleString("en-US", {
    hour: "numeric",
    minute: "numeric",
    hour12: true,
  });
  const message = {
    sender: messageSender,
    text: chatInput.value,
    timestamp,
  };

  /* Save message to local storage */
  messages.push(message);
  localStorage.setItem("messages", JSON.stringify(messages));

  /* Add message to DOM */
  chatMessages.innerHTML += createChatMessageElement(message);

  /* Clear input field */
  chatInputForm.reset();

  /*  Scroll to bottom of chat messages */
  chatMessages.scrollTop = chatMessages.scrollHeight;
};

chatInputForm.addEventListener("submit", sendMessage);

clearChatBtn.addEventListener("click", () => {
  localStorage.clear();
  chatMessages.innerHTML = "";
});

function dateDisplay() {
  //now is the whole date meaning, week-day month day year time time zone
  const now = new Date();
  //we want it to display week-day month day

  //the method getDay() returns the number that the day is in the week example Sunday is 0 so we made an array to show it as text
  const dayNames = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ];
  const monthNames = [
    "January",
    "Febuary",
    "March",
    "April",
    "May",
    "June",
    "July",
    "Augast",
    "September",
    "October",
    "November",
    "December",
  ];

  const currentDateTime = now.getDate();
  const currentDay = now.getDay(); //returns 1

  const currentMonth = now.getMonth(); // return 10

  document.querySelector("#datetime").textContent =
    dayNames[currentDay] +
    " " +
    monthNames[currentMonth] +
    " " +
    currentDateTime;
}
dateDisplay();
