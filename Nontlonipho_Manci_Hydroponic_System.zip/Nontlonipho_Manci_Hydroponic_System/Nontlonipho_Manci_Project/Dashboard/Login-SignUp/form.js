function signup(e){
    Event.preventDefault();

    var username = document.getElementById('Username').value;
    var password = document.getElementById('password').value;
    var email = document.getElementById('Username').value;

    if (!email || !username || !password) {
        alert('Please fill in all fields.');
        return;
    }

    var user = {
        email: email,
        username: username,
        password: password
    };

    var json = JSON.stringify(user);

    //storing entire 'user' object created under value key 'username'
    try {
        localStorage.setItem(username, json);
        alert('User has successfully registered');
    } catch (error) {
        console.log('Error while saving user data:', error);
    }
}

//login form
function loginFunc(e){
    e.preventDefault();

    const username = document.getElementById('Username').value;
    const password = document.getElementById('password').value;

    //check if username exists in localstorage
    if(localStorage.getItem(username)){
        const storedUser = JSON.parse(localStorage.getItem(username));

        if (password === storedUser.password) {
            alert('Login Successful');

            //if incorrect user must try again

        }else{
            alert('Incorrect password. Please try again.');
        }
    }else{
        alert('Username not found. Please register');
    }

    //add encryption
    

}

function showLogin() {
    document.getElementById("login-form").style.display = "block";
    document.getElementById("signup-form").style.display = "none";
  }

  function showSignup() {
    document.getElementById("login-form").style.display = "none";
    document.getElementById("signup-form").style.display = "block";
  }


//dummy data for login
const UserData = [ {
    email: 'John@gmail.com',
    username: 'John',
    password: 'John101'
},
{
    email: 'user@gmail.com',
    username: 'user',
    password: 'user'
},
{
    email: 'Vusimadhlope@gmail.com',
    username: 'vusim',
    password: '102030'
},
{
    email: 'Nelisiwe@gmail.com',
    username: 'NeliShereen',
    password: 'NeliM'
},
{
    email: 'Sintle23@gmail.com',
    username: 'Sintle23',
    password: 'Sintle23'
},
{
    email: 'NicB@gmail.com',
    username: 'NicB01',
    password: 'NicB01'
},
{
    email: 'Nontlonipho@gmail.com',
    username: 'Nontlonipho',
    password: 'Nontlonipho'
},
];

//storing the dummy data in local storage
UserData.forEach(function(userD){
    const json = JSON.stringify(userD);
    localStorage.setItem(userD.email, userD.username, userD.password, json);
});
