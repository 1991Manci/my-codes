var sidebarOpen = false;
var sidebar = document.getElementById("sidebar")

function openSidebar() {
    if (!sidebarOpen) {
        sidebar.classList.add("sidebar-responsive");
        sidebarOpen = true;
}
}

function closeSidebar() {
    if (sidebarOpen) {
        sidebar.classList.remove("sidebar-responsive");
        sidebarOpen = false;
    }
}

const searchForm = document.querySelector('.search-container');
    const searchInput = searchForm.querySelector('input');
    const searchButton = searchForm.querySelector('button');

    searchForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const searchTerm = searchInput.value.trim().toLowerCase();
        [gallery, settings. chacklist, alerts , community]
    });


//area bar 

var areaChartOptions = {
    series: [{
    name: "Temperature Balance",
   
    data: [31, 40, 28, 51, 42, 109, 100]
  }, {
    name: "Water Balance",
   
    data: [11, 32,45,32,34,52,41]
  }],
    chart: {
    height: 350,
    type: "area",
    toolbar: {
        show: false,
    }
  },
  colors: ["green", "yellow"],
  dataLabels: {
    enabled: false,
  },

  stroke: {
    curve: 'smooth'
  },
  labels: ['Nov 10','Nov 11','Nov 12','Nov 13','Nov 14 ','Nov 15','Nov 16'],
  markers: {
    size: 0
  },
  yaxis: [
    {
      title: {
        text: "",
      },
    },
    {
      opposite: true,
      title: {
        text: "",
      },
    },
  ],
  tooltip: {
    shared: true,
    intersect: false,
   
  }
  };

  var areaChart = new ApexCharts(document.querySelector("#area-chart"), areaChartOptions );
  areaChart.render();








